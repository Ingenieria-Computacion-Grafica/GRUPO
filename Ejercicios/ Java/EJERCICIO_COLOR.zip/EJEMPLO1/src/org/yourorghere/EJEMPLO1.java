package org.yourorghere;
import com.sun.opengl.util.Animator;
import java.awt.Frame;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.media.opengl.GL;
import javax.media.opengl.GLAutoDrawable;
import javax.media.opengl.GLCanvas;
import javax.media.opengl.GLEventListener;
import javax.media.opengl.glu.GLU;



/**
 * EJEMPLO1.java <BR>
 * author: Brian Paul (converted to Java by Ron Cemer and Sven Goethel) <P>
 *
 * This version is equal to Brian Paul's version 1.2 1999/10/21
 */
public class EJEMPLO1 implements GLEventListener {
    
    float rx=0, rx1=0;

    public static void main(String[] args) {
        Frame frame = new Frame("Simple JOGL Application");
        GLCanvas canvas = new GLCanvas();

        canvas.addGLEventListener(new EJEMPLO1());
        frame.add(canvas);
        frame.setSize(640, 480);
        final Animator animator = new Animator(canvas);
        frame.addWindowListener(new WindowAdapter() {

            @Override
            public void windowClosing(WindowEvent e) {
                // Run this on another thread than the AWT event queue to
                // make sure the call to Animator.stop() completes before
                // exiting
                new Thread(new Runnable() {

                    public void run() {
                        animator.stop();
                        System.exit(0);
                    }
                }).start();
            }
        });
        // Center frame
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        animator.start();
    }

    public void init(GLAutoDrawable drawable) {
        // Use debug pipeline
        // drawable.setGL(new DebugGL(drawable.getGL()));

        GL gl = drawable.getGL();
        System.err.println("INIT GL IS: " + gl.getClass().getName());

        // Enable VSync
        gl.setSwapInterval(1);

        // Setup the drawing area and shading mode
        gl.glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
//        gl.glShadeModel(GL.GL_FLAT); // try setting this to GL_FLAT and see what happens.
        gl.glShadeModel(GL.GL_SMOOTH);

        gl.glEnable(GL.GL_DEPTH_TEST);
        gl.glEnable(GL.GL_BLEND);
        gl.glBlendFunc(GL.GL_SRC_ALPHA,GL.GL_ONE_MINUS_SRC_ALPHA);// Activamos el canal alpha
    }

    public void reshape(GLAutoDrawable drawable, int x, int y, int width, int height) {
        GL gl = drawable.getGL();
        GLU glu = new GLU();

        if (height <= 0) { // avoid a divide by zero error!
        
            height = 1;
        }
        final float h = (float) width / (float) height;
        gl.glViewport(0, 0, width, height);
        gl.glMatrixMode(GL.GL_PROJECTION);
        gl.glLoadIdentity();
        glu.gluPerspective(45.0f, h, 1.0, 20.0);
        gl.glMatrixMode(GL.GL_MODELVIEW);
        gl.glLoadIdentity();
    }

    public void display(GLAutoDrawable drawable) {
        GL gl = drawable.getGL();

        // Clear the drawing area
        gl.glClear(GL.GL_COLOR_BUFFER_BIT | GL.GL_DEPTH_BUFFER_BIT);
        // Reset the current matrix to the "identity"
        gl.glLoadIdentity();

     

        // Move the "drawing cursor" around
        //gl.glTranslatef(-1.5f, 0.0f, -6.0f);
         gl.glTranslatef(0f, 0.0f, -5.0f);
         gl.glRotatef(rx,1,0,0);
        // Drawing Using Triangles
        
        gl.glBegin(GL.GL_LINE_LOOP); // Cierra Autom�ticamente los puntos
            gl.glColor3f(1.0f, 0.0f, 0.0f);    // Set the current drawing color to red
            gl.glVertex2f(0.0f, 1.0f);   // Top
            gl.glColor3f(0.0f, 1.0f, 0.0f);    // Set the current drawing color to green
            gl.glVertex2f(-1.0f, -1.0f); // Bottom Left
            gl.glColor3f(0.0f, 0.0f, 1.0f);    // Set the current drawing color to blue
            gl.glVertex2f(1.0f, -1.0f);  // Bottom Right
        // Finished Drawing The Triangle
        gl.glEnd();
        
        gl.glLoadIdentity();

         gl.glTranslatef(0f, 0.0f, -6.0f);
         gl.glRotatef(rx1,1,1f,1);
        
        gl.glBegin(GL.GL_TRIANGLES);
            gl.glColor4f(1.0f, 0.0f, 0.0f,.7f);    // Set the current drawing color to red
            gl.glVertex2f(0.0f, 1.0f);   // Top
            gl.glColor4f(0.0f, 1.0f, 0.0f,.7f);    // Set the current drawing color to green
            gl.glVertex2f(-1.0f, -1.0f); // Bottom Left
            gl.glColor4f(0.0f, 0.0f, 1.0f,.7f);    // Set the current drawing color to blue
            gl.glVertex2f(1.0f, -1.0f);  // Bottom Right
        // Finished Drawing The Triangle
        gl.glEnd();
        
        gl.glLoadIdentity();

         gl.glTranslatef(-2f, 0.0f, -5.0f);
         gl.glRotatef(rx,0,1f,1);
        
        gl.glBegin(GL.GL_LINE_STRIP); //Se tiene que introducir las coordenadas primer v�rtice al �ltimo, para poder cerrar una figura
            gl.glColor3f(.8f, 0.8f, 0f);    // Set the current drawing color to red
            gl.glVertex2f(-1.0f, 1.0f);   // Top
            gl.glColor3f(.8f, 0f, 0f);    // Set the current drawing color to red
            gl.glVertex2f(1.0f, 1.0f);
            gl.glColor3f(0.0f, 0.8f, 0.8f);    // Set the current drawing color to green
            gl.glVertex2f(1.0f, -1.0f); // Bottom Left
            gl.glColor3f(0.8f, 0.0f, 0.8f);    // Set the current drawing color to blue
            gl.glVertex2f(-1.0f, -1.0f);  // Bottom Right
            gl.glColor4f(0f, 0.0f, 1f,.8f);
            
            
//            gl.glColor3f(.8f, 0.8f, 0f); PARA CORREGIR EL COLOR SE PONE EL MISMO
            gl.glVertex2f(-1.0f, 1.0f);
        // Finished Drawing The Triangle
        gl.glEnd();
//       GL.GL_Q


//        gl.glBegin(GL.GL_QUAD_STRIP); //Se tiene que introducir las coordenadas primer v�rtice al �ltimo, para poder cerrar una figura
//            gl.glColor4f(.8f, 0.8f, 0f,.4f);    // Set the current drawing color to red
//            gl.glVertex2f(-1.0f, 1.0f);   // Top
//            gl.glColor4f(.8f, 0f, 0f,.4f);    // Set the current drawing color to red
//            gl.glVertex2f(1.0f, 1.0f);
//            gl.glColor4f(0.0f, 0.8f, 0.8f,.4f);    // Set the current drawing color to green
//            gl.glVertex2f(1.0f, -1.0f); // Bottom Left
//            gl.glColor4f(0.8f, 0.0f, 0.8f,.4f);    // Set the current drawing color to blue
//            gl.glVertex2f(-1.0f, -1.0f);  // Bottom Right
////            gl.glColor4f(0f, 0.0f, 1f,0f);
//    gl.glColor4f(.8f, 0.8f, 0f,.4f);
//            gl.glVertex2f(-1.0f, 1.0f);
//        // Finished Drawing The Triangle
//        gl.glEnd();
        
        
        
        
        
        gl.glBegin(GL.GL_QUADS); //Se tiene que introducir las coordenadas primer v�rtice al �ltimo, para poder cerrar una figura //GL_QUAD_STRIP
            gl.glColor4f(.8f, 0.8f, 0f,.4f);    // Set the current drawing color to red
            gl.glVertex2f(-1.0f, 1.0f);   // Top
            gl.glColor4f(.8f, 0f, 0f,.4f);    // Set the current drawing color to red
            gl.glVertex2f(1.0f, 1.0f);
            gl.glColor4f(0.0f, 0.8f, 0.8f,.4f);    // Set the current drawing color to green
            gl.glVertex2f(1.0f, -1.0f); // Bottom Left
            gl.glColor4f(0.8f, 0.0f, 0.8f,.4f);    // Set the current drawing color to blue
            gl.glVertex2f(-1.0f, -1.0f);  // Bottom Right
            gl.glColor4f(0f, 0.0f, 1f,1f);
    
            gl.glVertex2f(-1.0f, 1.0f);
        // Finished Drawing The Triangle
        gl.glEnd();
        
        
        gl.glLoadIdentity();
        gl.glTranslatef(1f, 0.0f, -5f);
        gl.glRotatef(rx,0,1,0);
        
        
        //**/DIFERENCIA ENTRE TRIANGLE FAN Y TRIANGLE STRIP
        
//        gl.glBegin (gl.GL_TRIANGLE_FAN);
//        gl.glColor3f(1,0,0);
//            gl.glVertex3f (0, 0, 0);
//            gl.glVertex3f (.50f, 0, 0);
//            gl.glVertex3f (.25f, .50f, 0);
//            gl.glVertex3f (.75f, .50f, 0);
//            gl.glVertex3f (.50f, .100f, 0);
//        gl.glEnd ();
        gl.glLoadIdentity();
        gl.glTranslatef(1f, 0.0f, -4.0f);
        
        
        gl.glBegin (gl.GL_TRIANGLE_STRIP);
        gl.glColor4f(1,1,0,.5F);
            gl.glVertex3f (0, 0, 0);
            gl.glVertex3f (.50f, 0, 0);
            gl.glVertex3f (.25f, .50f, 0);
            gl.glVertex3f (.75f, .50f, 0);
//            gl.glColor3i(255,0,0);
//            gl.glVertex3f (.50f, .100f, 0);
        gl.glEnd ();
        
        rx+=1f;
        rx1-=2f;
        gl.glFlush();

        // Flush all drawing operations to the graphics card
        gl.glFlush();
    }

    public void displayChanged(GLAutoDrawable drawable, boolean modeChanged, boolean deviceChanged) {
    }
}

