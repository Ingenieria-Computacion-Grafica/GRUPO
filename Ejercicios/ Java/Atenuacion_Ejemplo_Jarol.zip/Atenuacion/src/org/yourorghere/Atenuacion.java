package org.yourorghere;

import com.sun.opengl.util.Animator;
import java.awt.Frame;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.media.opengl.GL;
import javax.media.opengl.GLAutoDrawable;
import javax.media.opengl.GLCanvas;
import javax.media.opengl.GLEventListener;
import javax.media.opengl.glu.GLU;



/**
 * Atenuacion.java <BR>
 * author: Brian Paul (converted to Java by Ron Cemer and Sven Goethel) <P>
 *
 * This version is equal to Brian Paul's version 1.2 1999/10/21
 */
public class Atenuacion implements GLEventListener {
OBJModel1 model2;
float i;
static Linterna linterna2, lin3,lin4;
public  float [] position_lint={-15,30,11,1};  //declaramos un arreglo
        //float [] ambient_lint={0f,0f,0}; 
      public  float [] ambient_lint={0f,0f,0f}; 
      public  float [] diffuse_lint={1f,1f,1f};
      public  float [] specular_lint={1f,0f,1f};
       public float [] spot_direction={0,1,-.85f};
        
      public  float [] position_post={34f,30,-26,1};  //declaramos un arreglo
      public  float [] ambient_post={0f,0f,0}; 
//      public  float [] diffuse_post={0.9f,0f,0f};
      public  float [] diffuse_post={0f,1f,1f};
      public  float [] specular_post={1f,1f,1f};
      public  float [] spot_direction_post={1,-.85f,0};
    
    public static void main(String[] args) {
        Frame frame = new Frame("Simple JOGL Application");
        GLCanvas canvas = new GLCanvas();

        canvas.addGLEventListener(new Atenuacion());
        frame.add(canvas);
        frame.setSize(640, 480);
        final Animator animator = new Animator(canvas);
        frame.addWindowListener(new WindowAdapter() {

            @Override
            public void windowClosing(WindowEvent e) {
                // Run this on another thread than the AWT event queue to
                // make sure the call to Animator.stop() completes before
                // exiting
                new Thread(new Runnable() {

                    public void run() {
                        animator.stop();
                        System.exit(0);
                    }
                }).start();
            }
        });
        // Center frame
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        animator.start();
    }

    public void init(GLAutoDrawable drawable) {
        // Use debug pipeline
        // drawable.setGL(new DebugGL(drawable.getGL()));

        GL gl = drawable.getGL();
        System.err.println("INIT GL IS: " + gl.getClass().getName());

        // Enable VSync
        gl.setSwapInterval(1);
        Materiales.diccionario(gl);
        // Setup the drawing area and shading mode
        gl.glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
        gl.glShadeModel(GL.GL_SMOOTH); // try setting this to GL_FLAT and see what happens.
//        gl.glShadeModel(GL.GL_SMOOTH); // try setting this to GL_FLAT and see what happens.
        gl.glEnable(GL.GL_DEPTH_TEST);
        gl.glEnable(GL.GL_BLEND);
        gl.glBlendFunc(GL.GL_SRC_ALPHA,GL.GL_ONE_MINUS_SRC_ALPHA);
        gl.glEnable(GL.GL_TEXTURE_2D);
        gl.glEnable(GL.GL_LIGHTING);     //ACTIVAMOS LAS LUCES del parametro GlOBAL, Deja de funcionar el Color3f
//        gl.glEnable(GL.GL_LIGHT0);      //activa la luz cero
//        gl.glEnable(GL.GL_LIGHT1);
//        gl.glEnable(GL.GL_LIGHT2);
//        gl.glEnable(GL.GL_LIGHT3);
//        gl.glEnable(GL.GL_LIGHT4);
//        gl.glEnable(GL.GL_LIGHT5);
//        gl.glEnable(GL.GL_LIGHT6);
//        gl.glEnable(GL.GL_LIGHT7);
        gl.glEnable(GL.GL_TEXTURE_2D);
        gl.glEnable(GL.GL_NORMALIZE);
        model2 = new OBJModel1("src/Personaje.obj",
                                0,01,-3,
                                .25f,.25f,.25f,
                                0,0,0,
                                Materiales.materiales.get("roj") );
        linterna2= new Linterna(position_lint,ambient_lint,diffuse_lint,specular_lint,GL.GL_LIGHT2,gl,spot_direction,180,3); 
         lin3= new Linterna(position_post,ambient_post,diffuse_post,specular_post,GL.GL_LIGHT3,gl,spot_direction_post,180,3);
    }

    public void reshape(GLAutoDrawable drawable, int x, int y, int width, int height) {
        GL gl = drawable.getGL();
        GLU glu = new GLU();

        if (height <= 0) { // avoid a divide by zero error!
        
            height = 1;
        }
        final float h = (float) width / (float) height;
        gl.glViewport(0, 0, width, height);
        gl.glMatrixMode(GL.GL_PROJECTION);
        gl.glLoadIdentity();
        glu.gluPerspective(45.0f, h, 0.1, 200.0);
        gl.glMatrixMode(GL.GL_MODELVIEW);
        gl.glLoadIdentity();
    }

    public void display(GLAutoDrawable drawable) {
        GL gl = drawable.getGL();
        GLU glu= new GLU (); 
        // Clear the drawing area
        gl.glClear(GL.GL_COLOR_BUFFER_BIT | GL.GL_DEPTH_BUFFER_BIT);
        // Reset the current matrix to the "identity"
        gl.glLoadIdentity();
//        glu.gluLookAt(model2.x,10,model2.z,model2.x,0,model2.z,1,0,0);
        glu.gluLookAt(model2.x,4,model2.z-5,model2.x,0,model2.z+2,0,1,0);
        model2.DrawModel1(gl);
//
//        // Move the "drawing cursor" around
//        gl.glTranslatef(-1.5f, 0.0f, -6.0f);
//
//        // Drawing Using Triangles
//        gl.glBegin(GL.GL_TRIANGLES);
//            gl.glColor3f(1.0f, 0.0f, 0.0f);    // Set the current drawing color to red
//            gl.glVertex3f(0.0f, 1.0f, 0.0f);   // Top
//            gl.glColor3f(0.0f, 1.0f, 0.0f);    // Set the current drawing color to green
//            gl.glVertex3f(-1.0f, -1.0f, 0.0f); // Bottom Left
//            gl.glColor3f(0.0f, 0.0f, 1.0f);    // Set the current drawing color to blue
//            gl.glVertex3f(1.0f, -1.0f, 0.0f);  // Bottom Right
//        // Finished Drawing The Triangle
//        gl.glEnd();
//
//        // Move the "drawing cursor" to another position
//        gl.glTranslatef(3.0f, 0.0f, 0.0f);
//        // Draw A Quad
//        gl.glBegin(GL.GL_QUADS);
//            gl.glColor3f(0.5f, 0.5f, 1.0f);    // Set the current drawing color to light blue
//            gl.glVertex3f(-1.0f, 1.0f, 0.0f);  // Top Left
//            gl.glVertex3f(1.0f, 1.0f, 0.0f);   // Top Right
//            gl.glVertex3f(1.0f, -1.0f, 0.0f);  // Bottom Right
//            gl.glVertex3f(-1.0f, -1.0f, 0.0f); // Bottom Left
//        // Done Drawing The Quad
//        gl.glEnd();
        linterna2.ConfigurarLuz();
        linterna2.ActivarLuz();
//        linterna2.DesactivarLuz();
        linterna2.position[0]=model2.x;
        linterna2.position[1]=5;
        linterna2.position[2]=model2.z;
        
//        linterna2.spot_direction[0]=(float)  Math.cos(-Math.toRadians(cam1.getry())+90);
//        linterna2.spot_direction[2]=-(float) Math.sin(-Math.toRadians(cam1.getry())+90);
        
//        gl.glPopMatrix();
//        
//        lin3.ActivarLuz();
//        gl.glPushMatrix();

//        lin3.DisplayFoco();

        lin3.ConfigurarLuz();
        lin3.ActivarLuz();
        lin3.position[0]+=(float)Math.sin(model2.x+i);
        lin3.position[1]=5;
        lin3.position[2]+=-(float)Math.cos(model2.z+i);
        // Flush all drawing operations to the graphics card
        i+=.25f;
        gl.glFlush();
    }

    public void displayChanged(GLAutoDrawable drawable, boolean modeChanged, boolean deviceChanged) {
    }
}

