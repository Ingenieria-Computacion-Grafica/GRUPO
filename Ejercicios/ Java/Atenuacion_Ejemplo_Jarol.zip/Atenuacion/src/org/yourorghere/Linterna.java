/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.yourorghere;

import javax.media.opengl.GL;

/**
 *
 * @author fing.labcom
 */
public class Linterna extends LUZ {
    float [] spot_direction;
    float spot_cutoff;
    int spot_exponent;


    public Linterna(float[] position,float[] ambient, float[] diffuse, float[] specular, 
            int id, GL gl,float[] spot_direction, float spot_cutoff, int spot_exponent)  {
        super( position, ambient,diffuse, specular,id,gl);
        this.spot_direction = spot_direction;
        this.spot_cutoff = spot_cutoff;
        this.spot_exponent = spot_exponent;
    }
    public void ConfigurarLuz(){
        super.ConfigurarLuz();
    
            gl.glLightf(id,GL.GL_SPOT_CUTOFF, spot_cutoff);//ambient es lo mismo que poner this.ambient
            gl.glLightfv(id,GL.GL_SPOT_DIRECTION, spot_direction,0);
            gl.glLighti(id,GL.GL_SPOT_EXPONENT, spot_exponent);
//            gl.glLighti(id,GL.GL_CONSTANT_ATTENUATION,1);
//            gl.glLightf(id,GL.GL_LINEAR_ATTENUATION,0);
            gl.glLightf(id,GL.GL_QUADRATIC_ATTENUATION,.003f);
            
    

}
}
